package client.application;

import client.view.ChatRoomClientGUI;

public class ChatRoomClientStartup {
	
	
	public static void main(String[] args) {
		new ChatRoomClientGUI().start();
	}
}
