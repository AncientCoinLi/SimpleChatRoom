package client.model;

public enum EncryptType {
	AES, SHAMIR, RSA;
}
